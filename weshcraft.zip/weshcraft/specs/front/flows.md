# Navigation and flows

```mermaid
flowchart LR
  subgraph fn_home["Home"]
    scr_home["Home"]
  end
  subgraph fn_screen_2["Screen 2"]
    scr_screen_2["Screen 2"]
  end
```

| From | Element | To | Transition |
|---|---|---|---|
| — | — | — | — |

## Notes

<!-- weshcraft:notes:start -->
_No notes yet. Agent or human additions go here; WeshCraft keeps this block when it regenerates the file._
<!-- weshcraft:notes:end -->

<!-- weshcraft:contract
{
 "edges": [],
 "kind": "front-flows",
 "sourceHash": "d679a4f8e925dd14"
}
-->
