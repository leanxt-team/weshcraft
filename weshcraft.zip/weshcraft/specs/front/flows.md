# Navigation and flows

```mermaid
flowchart LR
  scr_home["Home"]
```

| From | Element | To | Transition |
|---|---|---|---|
| — | — | — | — |

## Notes

<!-- weshcraft:notes:start -->
_No notes yet. Agent or human additions go here; WeshCraft keeps this block when it regenerates the file._
<!-- weshcraft:notes:end -->

<!-- weshcraft:contract
{
 "edges": [],
 "kind": "front-flows",
 "sourceHash": "b60848651c1a4ed6"
}
-->
