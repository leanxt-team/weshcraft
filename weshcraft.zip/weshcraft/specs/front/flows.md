# Navigation and flows

```mermaid
flowchart LR
  scr_home["Home"]
  scr_screen_2["Screen 2"]
```

| From | Element | To | Transition |
|---|---|---|---|
| — | — | — | — |

## Notes

<!-- weshcraft:notes:start -->
_No notes yet. Agent or human additions go here; WeshCraft keeps this block when it regenerates the file._
<!-- weshcraft:notes:end -->

<!-- weshcraft:contract
{
 "edges": [],
 "kind": "front-flows",
 "sourceHash": "135899cd4543f8fd"
}
-->
