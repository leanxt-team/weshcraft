# Screen: Home

| | |
|---|---|
| Node | `#2` |
| Page | Page 1 |
| Frame | 1440 × 1024 px |
| Dev status | not marked |
| Fingerprint | `2f43ccf652aa` |
| Prototype | [prototype/index.html#scr-home](../../prototype/index.html#scr-home) |

## Purpose

Home is reached from outside the prototyped flows. It shows 0 text layers, 0 component instances and 0 interactions.

## Layout

Hierarchy, sizes and auto layout exactly as designed (px). Instances are specified in their component spec.

- `#2` **Home** — frame · 1440×1024 · clips

Root frame CSS (generated from the prototype):

```css
.scr-home {
  width: 1440px;
  height: 1024px;
  background: #ffffff;
  overflow: hidden;
  position: relative;
}
```

## Copy

Shown verbatim. Typography and colour per layer; contrast is WCAG 2.1 against the nearest filled ancestor.

| Node | Layer | Text | Typography | Colour | Contrast |
|---|---|---|---|---|---|
| — | — | (no text) | | | |

## Components

No component instances.

## Interactions

No prototype interactions on this screen.

## Inputs

No input fields detected.

## Front ⇄ back links

This screen has no back-end link (static content or navigation only).

## Design tokens used

None bound; raw colours: #ffffff

## Acceptance criteria

1. Renders at 1440 × 1024 px with the hierarchy, spacing and sizes in §Layout; a pixel comparison with the prototype render shows no difference above the project tolerance.
2. Every text in §Copy is shown verbatim with its typography and colour.

## Notes

<!-- weshcraft:notes:start -->
_No notes yet. Agent or human additions go here; WeshCraft keeps this block when it regenerates the file._
<!-- weshcraft:notes:end -->

<!-- weshcraft:contract
{
 "actions": [],
 "components": [],
 "copy": [],
 "fingerprint": "2f43ccf652aa",
 "inputs": [],
 "instances": [],
 "key": "scr-home",
 "kind": "front-screen",
 "links": [],
 "node": 2,
 "operations": [],
 "size": [
  1440,
  1024
 ],
 "sourceHash": "b60848651c1a4ed6"
}
-->
