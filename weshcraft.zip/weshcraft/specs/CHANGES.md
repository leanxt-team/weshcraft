# Design changelog

Every regeneration that changed the prototype, newest first. Written by WeshCraft from the manifest; `#id` cites the layer.

<!-- weshcraft:change b60848651c1a4ed6 -->
### 2026-11-04 10:18 UTC · `f3439d0656eb5a1a` → `b60848651c1a4ed6`

- + Screen **Home** added
