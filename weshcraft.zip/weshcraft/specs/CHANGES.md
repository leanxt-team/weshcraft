# Design changelog

Every regeneration that changed the prototype, newest first. Written by WeshCraft from the manifest; `#id` cites the layer.

<!-- weshcraft:change d679a4f8e925dd14 -->
### 2026-11-04 14:55 UTC · `087111e740c6e06e` → `d679a4f8e925dd14`


<!-- weshcraft:change 087111e740c6e06e -->
### 2026-11-04 12:50 UTC · `c3f5329fb06b61d9` → `087111e740c6e06e`

- ~ Screen 2: frame 1440×1024 → 979×1024

<!-- weshcraft:change c3f5329fb06b61d9 -->
### 2026-11-04 12:50 UTC · `135899cd4543f8fd` → `c3f5329fb06b61d9`

- ~ Screen 2: layout or styling changed

<!-- weshcraft:change 135899cd4543f8fd -->
### 2026-11-04 11:06 UTC · `b60848651c1a4ed6` → `135899cd4543f8fd`

- + Screen **Screen 2** added

<!-- weshcraft:change b60848651c1a4ed6 -->
### 2026-11-04 10:18 UTC · `f3439d0656eb5a1a` → `b60848651c1a4ed6`

- + Screen **Home** added
