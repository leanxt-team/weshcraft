# Domain model

Entities and fields the prototype displays or edits. Types come from explicit bindings; inferred fields default to `string` until confirmed.

No data-bearing elements were found. Bind layers to data (WeshCraft: Spec section › Shows, or `design_bind`; FigCraft: the conventions below) to make them part of the contract:

- text content `{{trail.name}}` or `{{trail.distance:number}}`
- a layer name `@trail.rating:number`
- layer data `set_properties {props: {pluginData: {weshcraft: "{\"entity\":\"Trail\",\"field\":\"name\"}"}}}`
## Notes

<!-- weshcraft:notes:start -->
_No notes yet. Agent or human additions go here; WeshCraft keeps this block when it regenerates the file._
<!-- weshcraft:notes:end -->

<!-- weshcraft:contract
{
 "entities": [],
 "kind": "back-domain",
 "sourceHash": "ff861a3bc508b058"
}
-->
