# Spec ↔ prototype parity

✅ **In sync.** 49 checks, 0 errors, 1 warnings, score 100%. Prototype `d679a4f8e925dd14` (2 screens, 0 components, 0 tokens, 0 operations).

| Level | Check | File | Detail |
|---|---|---|---|
| warning | functions-suggested | `specs/FUNCTIONS.md` | the 2 functions are suggested from the prototype: name them and give each a purpose (design_functions or the Functions view) |
