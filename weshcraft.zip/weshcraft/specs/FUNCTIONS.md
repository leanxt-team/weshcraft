# How the product works

2 functions: [Home](#fn-home) · [Screen 2](#fn-screen-2). Who uses each one, the data it reads and writes, and where it leads. The screen, API and map specs refer to these functions.

**Suggested.** These functions are grouped from the prototype (flows, sections, navigation, API tags). Name them and give each a purpose (`design_functions`, or the Functions view) to make them the product's.

```mermaid
flowchart LR
  subgraph Who
    actor_user(["People (app)"])
  end
  subgraph Functions
    fn_home["Home"]
    fn_screen_2["Screen 2"]
  end
  actor_user --> fn_home
  actor_user --> fn_screen_2
```

Legend: ⇒ leads to (the user moves on to) · → writes · ⇢ reads.

<a id="fn-home"></a>
## Home

_Purpose not described yet._

| | |
|---|---|
| Who | People (app) |
| Screens | [Home](front/screens/scr-home.md) |
| Data | — |
| Leads to | — |

<a id="fn-screen-2"></a>
## Screen 2

_Purpose not described yet._

| | |
|---|---|
| Who | People (app) |
| Screens | [Screen 2](front/screens/scr-screen-2.md) |
| Data | — |
| Leads to | — |

## Notes

<!-- weshcraft:notes:start -->
_Product notes: goals, what is out of scope, open questions._
<!-- weshcraft:notes:end -->

<!-- weshcraft:contract
{
 "declared": false,
 "functions": [
  {
   "entities": [],
   "key": "fn-home",
   "name": "Home",
   "next": [],
   "operations": [],
   "screens": [
    "scr-home"
   ],
   "summary": "",
   "tools": []
  },
  {
   "entities": [],
   "key": "fn-screen-2",
   "name": "Screen 2",
   "next": [],
   "operations": [],
   "screens": [
    "scr-screen-2"
   ],
   "summary": "",
   "tools": []
  }
 ],
 "kind": "functions",
 "sourceHash": "d679a4f8e925dd14",
 "unassigned": {
  "operations": [],
  "screens": [],
  "tools": []
 }
}
-->
