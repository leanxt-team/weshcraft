# WeshCraft for OpenCode and OpenChamber

Two parts in this repository, used together:

| | What it adds | Where |
|---|---|---|
| **OpenCode plugin** (`opencode/plugin.mjs`) | WeshCraft's tools for the agent (`design_*`, `weshcraft_*`), the `/weshcraft` command, and the WeshCraft server for the project | OpenCode 2.2+, and OpenChamber (it runs on the OpenCode server) |
| **OpenChamber extension** (`openchamber/`, manifest in `package.json`) | **Small panel**: sync status with GitHub / GitLab / this repository. **Big panel**: the whole WeshCraft desktop interface, in OpenChamber's theme | OpenChamber 2.0.1+, web and desktop |

## Install

1. The plugin, for every project on this machine (OpenCode and OpenChamber read the same folder):

   ```bash
   node /path/to/weshcraft/bin/weshcraft.mjs init --client opencode --global
   ```

   or for one project (commit `.opencode/` to share it): `init --client opencode`.
2. The extension: in OpenChamber, **Settings → Extensions**, paste the path of your WeshCraft folder (or its git URL) into **Folder, ZIP, or URL**, choose **Add**, and allow it. It asks for one permission: a local service, which runs this project's WeshCraft.
3. Restart OpenCode / reload OpenChamber.

## The small panel (sync status)

On the rail, and as a **WeshCraft sync** section in Work Status:

- where the specs go: a GitHub or GitLab repository and branch, or this repository's git;
- the state: Synced (with the commit), Syncing, Waiting (the specs are out of sync with the design: only matching specs are synced), Sync failed (with the reason, and a dot on the rail icon), Not syncing;
- the pull / merge request (opens in the browser), recent syncs, **Sync now**, **Stop syncing**;
- when nothing is set up: GitHub · GitLab · Local git, repository, branch, pull request on/off, **Start syncing**.

The Work Status line shows the same state in one row; click it to open the pull request.

## The big panel (WeshCraft)

**Extension pages › WeshCraft** (the menu above the session list) opens the full desktop interface: design editor, prototype, spec builder, reader, front ⇄ back map, manifest, publish & sync. It uses OpenChamber's colours, font, radius and light/dark theme instead of WeshCraft's own Liquid Glass look, and follows the open project.

Each page is one self-contained HTML file (script and styles inline), so it works however an OpenChamber version serves package files. Extension pages cannot reach the network themselves, so the page talks to WeshCraft through the extension's service: API calls, live updates (long-polled), the prototype (loaded as HTML), uploads (sent in 45 KB chunks). Downloads and links to other sites open through OpenChamber (in the desktop app, in its browser panel).

## GitHub / GitLab access is inherited

No token to paste. WeshCraft uses, in this order:

1. a token typed in the publish dialog, if any;
2. `GITHUB_TOKEN` / `GH_TOKEN`, `GITLAB_TOKEN` / `GL_TOKEN` from OpenCode's environment;
3. **the account you signed in to in OpenChamber** (Settings › Integrations; read from `~/.config/openchamber`, or `$OPENCHAMBER_DATA_DIR`), including GitHub Enterprise and self-managed GitLab instances, and following OpenChamber's own choice when it is set to use your CLI login;
4. your `gh` / `glab` CLI login;
5. git's credential helper for the host (what `git push` uses).

The panel and the publish dialog say which one is used ("Access: your OpenChamber account (login)"); the token itself never leaves the WeshCraft server. Local git sync commits with your git setup and never switches branches.

## The plugin

- WeshCraft starts with the project: one `weshcraft serve` per project on a stable port, shared by every session, by the OpenChamber panels and by your browser; stopped when the plugin unloads.
- Tools: `design_*` (tree, find, get, edit — batched, one undo step —, text, bind, api, link, screen, tokens, undo/redo, new), `weshcraft_*` (status, generate, check, links, manifest, read_spec, write_notes, sync, publish, open) and `figcraft_*` with a live FigCraft. Every design change regenerates the specs; the user sees it live.
- A project with nothing to spec gets one tool, `weshcraft_start`; after it, `design_new` creates the design and the editing tools appear.
- `/weshcraft` gives the link, parity, front ⇄ back links and open questions.
- Settings: `.opencode/weshcraft.json` or the plugin's options in `opencode.json` (`file`, `surface`, `mcpServer`, `attach`, `figcraftCli`, `sync`, `port`, `token`). `--no-plugin` registers WeshCraft as an MCP server in `opencode.json` instead.

## Rebuild the extension pages

After editing `openchamber/src/` or the browser app (`src/web/public/`):

```bash
npm install
```

```bash
npm run build:openchamber
```

## When something is wrong

The panels and the page say it in place: "OpenChamber has not connected this panel yet" (enable WeshCraft in Settings → Extensions, OpenChamber 2.0.1+), "Allow the WeshCraft service…" (approve the service), "No GitHub access found" (sign in in OpenChamber or run `gh auth login`).
