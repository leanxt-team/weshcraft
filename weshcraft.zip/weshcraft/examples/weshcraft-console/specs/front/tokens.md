# Design tokens

The prototype defines no variables. Raw colours per screen are listed in each screen spec; consider creating tokens (WeshCraft: Tokens panel or `design_tokens`; FigCraft: `variable.create`) so code and design share names.

## Notes

<!-- weshcraft:notes:start -->
_No notes yet. Agent or human additions go here; WeshCraft keeps this block when it regenerates the file._
<!-- weshcraft:notes:end -->

<!-- weshcraft:contract
{
 "kind": "front-tokens",
 "sourceHash": "d69943427aa24a1d",
 "tokens": []
}
-->
